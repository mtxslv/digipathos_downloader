# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['digipathos_downloader']

package_data = \
{'': ['*']}

install_requires = \
['requests>=2.28.2,<3.0.0']

setup_kwargs = {
    'name': 'digipathos-downloader',
    'version': '0.1.0',
    'description': 'Digipathos plant disease image database (EMBRAPA) downloader based on georg-un project',
    'long_description': "# Intro\n\nThis fork makes [georg-un's installer](https://github.com/georg-un/digipathos-plant-disease-img-db-downloader) installable by pip or poetry. That is, it is not necessary to git-clone the repo. Just ```poetry add``` it and that is it..\n\n**original docs below**\n\n# Digipathos Plant Disease Image Database Downloader\nThis project is a downloader for the plant disease image database provided by EMBRAPA (Brazilian Agricultural Research Corporation). Further information on the database can be found in [this](https://doi.org/10.1016/j.biosystemseng.2018.05.013) paper.\n\n[![Codacy Badge](https://api.codacy.com/project/badge/Grade/70ab11e8a9284cac8abdac662facb22f)](https://www.codacy.com/app/georg-un/embrapa-plant-disease-img-db-downloader?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=georg-un/embrapa-plant-disease-img-db-downloader&amp;utm_campaign=Badge_Grade)\n\n## Requirements\nYou will need **python 3.6 or higher** installed.\nAdditionally, you will need the python module *requests*. If you haven't already installed it, install it with `pip install requests`.\n\n## Installation\n~~With [git](https://git-scm.com/downloads) installed, you can install the downloader with:~~\n```shell\n```\n\nJust do:\n```shell\npip install git+https://github.com/mtxslv/digipathos_downloader\n```\n\nor\n\n```shell\npoetry add git+https://github.com/mtxslv/digipathos_downloader\n```\n\n## Usage\nTo use the downloader, open a terminal in the project folder and run the following command:\n```shell\npython3.6 run.py\n```\n\n**Note:** You can tell the script to download only original or cropped images.<br/>\nTo download only original images use the command `python3.6 run.py original`.<br/>\nTo download only cropped images use the command `python3.6 run.py cropped`.\n",
    'author': 'Mateus Assis',
    'author_email': 'mateus.d.assis.silva@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
